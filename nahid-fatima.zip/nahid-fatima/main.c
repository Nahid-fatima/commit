
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
//declarer les structures
typedef struct date{
int jj;
int mm;
int aaaa;
}date;
typedef struct contratLocation
{
 float numContrat;
 int idVoiture;
 int idClient;
 date debut;
 date fin;
 int cout;
} contrat;
contrat cont;

typedef struct Client
{
 int idClient;
 char nom[20];
 char prenom[20];
 int cin;
 char adresse[15];
 int telephon;
}client;
typedef struct voiture{
 int idVoiture;
 char marque[5];
 char nomVoiture[15];
 char couleur[7];
 int nbplaces;
 int prixJour;
 char EnLocation[4];
} voiture;
 voiture v;
  client c;
//procedure affichage
void afficher_v(){
FILE *F; int c;
F=fopen("Voitures.txt","r");
printf("la liste des gestion de voiture est \n\n");
fseek(F,0,SEEK_SET);
do{
  c=fgetc(F);
printf("%c",c);
}while(c!=EOF);
fclose(F);
}
//proc�dure d'ajout
void ajouter_v(){
    FILE *F;
F=fopen("Voitures.txt","a");
printf("entrer les information de la voiture que vous voulez ajoute\n");
printf("\n idvoiture: ");
scanf("%d",&v.idVoiture);
printf("\n  la marque: ");
scanf("%s",v.marque);
printf("\n nom de voiture : ");
scanf("%s",v.nomVoiture);
printf("\n couleur de voiture : ");
scanf("%s",v.couleur);
printf("\n  nombre de place : ");
scanf("%d",&v.nbplaces);
printf("\n le prix par jour :  ");
scanf("%d",&v.prixJour);
printf("\n est ce que il est en location  :");//oui ou non
scanf("%s",v.EnLocation);

fprintf(F,"%d : %s : %s : %s : %d : %d : %s :\n", v.idVoiture, v.marque, v.nomVoiture,v.couleur,v.nbplaces,v.prixJour,v.EnLocation);
fclose(F);
}
//proc�dure modifier
void modifier_v(){
    int identiti;
    printf("entrer le numero d identiti que vous voulez modifier ");
    scanf("%d",&identiti);
   FILE *fp1=fopen("Voitures.txt","r");
    FILE *fp2=fopen("Voitures_mod.txt","w");
    do{
fscanf(fp1,"%d |%s |%s| %s |%d |%d |%s",&v.idVoiture,v.marque,v.nomVoiture,v.couleur,&v.nbplaces,&v.prixJour,v.EnLocation);
fflush(stdin);
        if(identiti==v.idVoiture){

            printf("le nouveau identiti : \n");
            scanf("%d",&v.idVoiture);
            printf(" la nouvelle marque : \n");
            scanf("%s",v.marque);
            printf(" le nouveau nom de voiture : \n");
            scanf("%s",v.nomVoiture);
            printf(" la nouvelle coleur :  \n");
            scanf("%s",v.couleur);
            printf("le nouveau nb de place : \n");
            scanf("%d",&v.nbplaces);
            printf("le nouveau prix : \n");
            scanf("%d",&v.prixJour);
            printf("le nouveau en location : \n");
            scanf("%s",v.EnLocation);	}
        fprintf(fp2,"%d  %s  %s  %s  %d  %d  %s",v.idVoiture,v.marque,v.nomVoiture,v.couleur,v.nbplaces,v.prixJour,v.EnLocation);
    }while(!feof(fp1));
    fclose(fp1);
    fclose(fp2);
    remove("Voitures.txt");
    rename("Voitures_mod.txt","Voitures.txt");}
//proc�dure suprrimer
void suprimer_v(){
    int identiti;
 FILE *fp1=fopen("Voitures.txt","r");
FILE *fp2=fopen("Voitures_sup.txt","a");
 printf("entrer l identiti du voiture a supprimer\n");
 scanf("%d",&identiti);
do{
fscanf(fp1,"%d : %s : %s : %s : %d : %d : %s :\n", &v.idVoiture, v.marque, v.nomVoiture,v.couleur,&v.nbplaces,&v.prixJour,v.EnLocation);
if(identiti!=v.idVoiture){
fprintf(fp2,"%d : %s : %s : %s : %d : %d : %s :\n", v.idVoiture, v.marque, v.nomVoiture,v.couleur,v.nbplaces,v.prixJour,v.EnLocation);
}
}while(!feof(fp1));
fclose(fp1);
fclose(fp2);
remove("Voitures.txt");
rename("voiture_sup.txt","voiture.txt");
 }
 //-------------------------------------------------------------------------------------------------------------------------------------/

 //procedure afficher client
 void afficher_c(){
FILE *F; int car;
F=fopen("Clients.txt","r");
printf("la liste des  client est \n\n");
fseek(F,0,SEEK_SET);
do{
  car=fgetc(F);
printf("%c",car);
fclose(F);
}while(car!=EOF);}

//procedure d'ajouter client
void ajouter_c(){
    FILE *F;
F=fopen("Clients.txt","a");
printf("entrer les information de client que vous voulez ajoute\n");
printf("\n entrer idclient ");
scanf("%d",&c.idClient);
printf("\n nom : ");
scanf("%s",c.nom);
printf("\n prenom :");
scanf("%s",c.prenom);
printf("\n CIN : ");
scanf("%d",&c.cin);
printf("\n adresse :");
scanf("%s",c.adresse);
printf("\n numero de telephone :");
scanf("%d",&c.telephon);
fprintf(F,"%d : %s : %s : %d : %s : %d \n", c.idClient, c.nom, c.prenom,c.cin,c.adresse,c.telephon);
fclose(F);
}
//proc�dure modifier
void modifier_c(){
    int identiti;
    printf("entrer l identiti de client que vous voulez modifier ");
    scanf("%d",&identiti);
   FILE *fp1=fopen("Clients.txt","r");
    FILE *fp2=fopen("Clients_mod.txt","w");
    do{
fscanf(fp1,"%d |%s |%s| %d |%s |%d ",&c.idClient,c.nom,c.prenom,&c.cin,c.adresse,&c.telephon);
fflush(stdin);
        if(identiti==c.idClient){
            printf("entre le nouveau identiti\n");
            scanf("%d",&c.idClient);
            printf("entre la nouvelle nom\n");
            scanf("%s",c.nom);
            printf("entre le nouveau prenom\n");
            scanf("%s",c.prenom);
            printf("entre le nouveau cin\n");
            scanf("%d",&c.cin);
            printf("entre le nouveau adresse\n");
            scanf("%s",c.adresse);
            printf("entre le nouveau numero de telephone\n");
            scanf("%d",&c.telephon);
        }
        fprintf(fp2,"%d : %s : %s : %d : %s : %d \n", c.idClient, c.nom, c.prenom,c.cin,c.adresse,c.telephon);

    }while(!feof(fp1));
    fclose(fp1);
    fclose(fp2);
    remove("Clients.txt");
    rename("Clients_mod.txt","Clients.txt");}
//proc�dure suprrimer
void suprimer_c(){
    int identiti;
 FILE *fp1=fopen("Clients.txt","r");
FILE *fp2=fopen("Client_sup.txt","a");
 printf("entrer l identiti du client a supprimer\n");
 scanf("%d",&identiti);
do{
    fscanf(fp1,"%d |%s |%s| %d |%s |%d ",&c.idClient,c.nom,c.prenom,&c.cin,c.adresse,&c.telephon);
if(identiti!=v.idVoiture){
            fprintf(fp2,"%d : %s : %s : %d : %s : %d \n", c.idClient, c.nom, c.prenom,c.cin,c.adresse,c.telephon);}
}while(!feof(fp1));
fclose(fp1);
fclose(fp2);
remove("Clients.txt");
rename("Clients_sup.txt","Clients.txt");
 }
//----------------------------------------------------------------------------------------------------------------------------------------/
//menu location
//visualiser le contrat
void recherche_affiche(){
  FILE *F;
  int numR;
  printf("entrer le numero du client a recherche ");
  scanf("%d",&numR);
  F=fopen("Contra2.txt","r");
  do{
    fscanf(F,"%f |%d |%d| %d%d%d|%d%d%d |%d",&cont.numContrat,&cont.idVoiture,&cont.idClient,&cont.debut.aaaa,&cont.debut.mm,&cont.debut.jj,&cont.fin.aaaa,&cont.fin.mm,&cont.fin.jj, &cont.cout);
    if(numR==cont.numContrat){
        printf("information sur le client est \n");
        printf("le num de contrat%f",cont.numContrat);
        printf("l idvoiture est %d",cont.idClient);
        printf("la date de debut est%d/%d/%d",cont.debut.jj,cont.debut.mm,cont.debut.aaaa);
        printf("la date de fin est %d/%d/%d",cont.fin.jj,cont.fin.mm,cont.fin.aaaa);
        printf(" le prix est %d",cont.cout);}}while(!feof(F));
        fclose(F);
    }
void louer(){
    int trouve_c=0,trouve_v=0;
    voiture vr;
    char nom[10];
    char prenom[5];
    printf("entrer votre nom\n");
    scanf("%s",nom);
    printf("entrer votre prenom\n");
    scanf("%s",prenom);
    printf(" entrer les information de la voiture que vous voulez louer\n");
    printf("\n idvoiture: ");
    scanf("%d",&vr.idVoiture);
    printf("\n  la marque: ");
    scanf("%s",vr.marque);
    printf("\n nom de voiture : ");
    scanf("%s",vr.nomVoiture);
    printf("\n couleur de voiture : ");
    scanf("%s",vr.couleur);
    printf("\n  nombre de place : ");
    scanf("%d",&vr.nbplaces);
    printf("\n le prix par jour :  ");
    scanf("%d",&vr.prixJour);
    FILE*fp1=fopen("Voitures.txt","a");
              FILE*fp2=fopen("Clients.txt","r");
    //chercher si le na voiture existe
    do{
           fscanf(fp2,"%d :%s :%s :%d :%s :%d",&c.idClient,c.nom,c.prenom,&c.cin,c.adresse,&c.telephon);

        if((nom==c.nom)&&(prenom==c.prenom))
        trouve_c=1;
}while(!feof(fp2));
if(trouve_c==1){
    do{
    fscanf(fp1,"%d : %s : %s : %s : %d : %d : %s :\n", &v.idVoiture, v.marque, v.nomVoiture,v.couleur,&v.nbplaces,&v.prixJour,v.EnLocation);

        if(vr.idVoiture==v.idVoiture){
           trouve_v=1;
           if(strcmp(v.EnLocation,"oui")==0)
            printf("la voiture n est pas disponible\n ");
            else{
                printf("la location est reusisir\n");
                printf("entrer votre donner pour cree votre contrat\n");
                printf("idClient :\n");
                scanf("%d",&c.idClient);
                printf("nom :\n");
                scanf("%s",c.nom);
                printf("prenom :\n");
                scanf("%s",c.prenom);
                printf("cin :");
                scanf("%d",&c.cin);
                printf("adresse :\n");
                scanf("%s",c.adresse);
                printf("telephone :\n");
                scanf("%d",&c.telephon);
                }	}
           if(trouve_v==0)
            printf("la voiture demander n existe pas ");}while(!feof(fp1));


}else
printf("enregistrer votre propres informations a travers le menu � Gestion clients ");}
void retourner_voiture(){
    int id_v;
    printf("entre l idvoiture\n");
    scanf("%d",&id_v);
    FILE *fp1=fopen("Voitures.txt","a");
        FILE *fp3=fopen("ContratsLocations_sup.txt","w");
        FILE*fp2=fopen("ContratsLocations.txt","r");


    do{
    fscanf(fp1,"%d : %s : %s : %s : %d : %d : %s :\n", &v.idVoiture, v.marque, v.nomVoiture,v.couleur,&v.nbplaces,&v.prixJour,v.EnLocation);
    if(id_v==v.idVoiture)
        printf("dgfhj");
    }while(!feof(fp1));
    do{
        fscanf(fp2,"%f :%d:%d :%d%d%d :%d%d%d:%d",&cont.numContrat,&cont.idVoiture,&cont.idClient,&cont.debut.aaaa,&cont.debut.mm,&cont.debut.jj,&cont.fin.aaaa,&cont.fin.mm,&cont.fin.jj,&cont.cout);
    if(id_v==cont.idVoiture){

        fprintf(fp3,"%f %d %d %d%d%d %d%d%d %d",cont.numContrat,cont.idVoiture,cont.idClient,cont.debut.aaaa,cont.debut.mm,cont.debut.jj,cont.fin.aaaa,cont.fin.mm,cont.fin.jj,cont.cout);
    }

    }while(!feof(fp2));
    fclose(fp2);
fclose(fp3);
remove("ContratsLocations.txt");
rename("ContratsLocations_sup.txt","ContratsLocations.txt");


}
void modifier_conte(){
    int num_c;
    printf("entrer le numero de contret que vous voulez modifier\n");
    scanf("%d",&num_c);
    FILE *fp1=fopen("ContratsLocations.txt","r");
    FILE *fp2=fopen("ContratsLocations_mod.txt","w");
    do{

    fscanf(fp1,"%f :%d:%d :%d%d%d :%d%d%d:%d",&cont.numContrat,&cont.idVoiture,&cont.idClient,&cont.debut.aaaa,&cont.debut.mm,&cont.debut.jj,&cont.fin.aaaa,&cont.fin.mm,&cont.fin.jj,&cont.cout);
     if(num_c==cont.numContrat){
        printf("entrer le nouveau date de reteur\n");
        scanf("%d",&cont.fin.aaaa);
        scanf("%d",&cont.fin.mm);
        scanf("%d",&cont.fin.jj);
     }
   fprintf(fp2,"%f %d %d %d%d%d %d%d%d %d",cont.numContrat,cont.idVoiture,cont.idClient,cont.debut.aaaa,cont.debut.mm,cont.debut.jj,cont.fin.aaaa,cont.fin.mm,cont.fin.jj,cont.cout);
    }while(!feof(fp1));
    fclose(fp1);
fclose(fp2);
remove("ContratsLocations.txt");
rename("ContratsLocations_mod.txt","ContratsLocations.txt");
}
void supprimer_conte(){
    int id_v;
    printf("entrer l identiti du voiture reteurner\n");
    scanf("%d",&id_v);
     FILE*fp1=fopen("ContratsLocations.txt","r");
    FILE*fp2=fopen("ContratsLocations_sup.txt","w");

        fscanf(fp1,"%f :%d:%d :%d%d%d :%d%d%d:%d",&cont.numContrat,&cont.idVoiture,&cont.idClient,&cont.debut.aaaa,&cont.debut.mm,&cont.debut.jj,&cont.fin.aaaa,&cont.fin.mm,&cont.fin.jj,&cont.cout);
do{
    if((id_v==v.idVoiture)&&(strcmp(v.EnLocation,"oui")==0))
    fprintf(fp2,"%f %d %d %d%d%d %d%d%d %d",cont.numContrat,cont.idVoiture,cont.idClient,cont.debut.aaaa,cont.debut.mm,cont.debut.jj,cont.fin.aaaa,cont.fin.mm,cont.fin.jj,cont.cout);


}while(!feof(fp1));
    fclose(fp1);
fclose(fp2);
remove("ContratsLocations.txt");
rename("ContratsLocations_sup.txt","ContratsLocations.txt");	}



//--------------------------------------------------------------------------------------------------------------------------------------------/

void Gestion_Voitures(){
    int choix;
    do{
    printf("1:Liste des voitures\n");
    printf("2:Ajouter voiture\n");
    printf("3:Modifier voiture\n");
    printf("4:Supprimer voiture\n");
    printf("5:Retour\n");
    printf("entrer votre choix\n");
    scanf("%d",&choix);

}while(choix >5 || choix <1);
    switch(choix){
    case 1:afficher_v();
    break;
    case 2:ajouter_v();
    break;
   case 3:modifier_v();
    break;
     case 4:suprimer_v();
    break;
    }
}
void Menu_Location(){
int choix;
do{
    printf("1:Visualiser contrat\n");
    printf("2:Louer voiture\n");
    printf("3:Retourner voiture\n");
    printf("4:Modifier voiture\n");
    printf("5:Supprimer contrat\n");
    printf("6:Retour");
    printf("entrer votre choix\n");
    scanf("%d",&choix);

}while(choix >6 || choix <1);
    switch(choix){
    case 1:recherche_affiche();
    break;
    case 2:louer();
    break;
   case 3:retourner_voiture();
    break;
     case 4: modifier_conte();
    break;
    case 5:supprimer_conte();
    break;
    }
}
void Gestion_clients()
{
int choix;
do{
    printf("1:Liste des clients\n");
    printf("2:Ajouter  clients\n");
    printf("3:Modifier client\n");
    printf("4:Supprimer client\n");
     printf("5:retour");
    printf("choisir votre choix\n");
    scanf("%d",&choix);

}while(choix >5 || choix <1);
    switch(choix){
    case 1:afficher_c();
    break;
    case 2:ajouter_c();
    break;
   case 3:modifier_c();
    break;
     case 4:suprimer_c();
    break;
    }


 }
 //--------------------------------------------------------------------------------------------------------------/
 void menu(){
    int choix;
    do{
    printf("1:Location\n");
    printf("2:Gestion voitures\n");
    printf("3:Gestion clients\n");
    printf("4:Quitter\n");
    printf("choisir votre  choix \n");
    scanf("%d",&choix);

}while(choix >5 || choix <1);
    switch(choix){
    case 1:Menu_Location();
    break;
    case 2:Gestion_Voitures();
    break;
   case 3:Gestion_clients();
    break;
 }}
//menu_principal

int main(){
 menu();
 return 0;}




